from setuptools import setup

setup  (
    name = "CVE-2022-21371",
    version = "0.0.1",
    description = "CVE-2022-21371 is a Bug scanner for WebPentesters and Bugbounty Hunters",
    #packages = ["cve202329489"],
    author = "@karthi-the-hacker",
    author_email = "contact@cappriciosec.com",
    license = "MIT",

    entry_points={
        'console_scripts': [
            'CVE-2022-21371=cve202221371.main:main',
        ]
    }

)