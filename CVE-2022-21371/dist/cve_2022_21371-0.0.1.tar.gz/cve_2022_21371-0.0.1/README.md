# CVE-2022-21371
Oracle WebLogic Server (LFI)
